<?php

require_once 'PHPUnit/Framework/TestCase.php';

class DashboardControllerTest extends PHPUnit_Framework_TestCase
{

    public function setUp()
    {
        /* Setup Routine */
    }

    public function tearDown()
    {
        /* Tear Down Routine */
    }


}

