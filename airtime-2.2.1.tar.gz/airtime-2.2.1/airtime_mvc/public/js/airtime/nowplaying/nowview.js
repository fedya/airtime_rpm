var viewType = "now";
