var viewType = "day";
