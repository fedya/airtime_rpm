$(document).ready(function() {
    $.ajaxSetup({
      cache: false
    });
});
