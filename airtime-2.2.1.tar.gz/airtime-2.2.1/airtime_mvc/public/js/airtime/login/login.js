$(window).load(function(){
    $("#username").focus();
})